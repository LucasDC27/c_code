#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <locale.h>

#define NOMEARQUIVO "20221206_leitos_internacoes.csv"
#define limite 2000

void organizar(int);
void shift_left(int);
void Mergefiles(int);

struct Filedata
{
    char datahora[50];
    char nome[50];
    double pacientes_uti_mm7d;
    double total_covid_uti_mm7d;
    double ocupacao_leitos;
    int pop;
    double leitos_pc;
    int internacoes_7d;
    int internacoes_7d_l;
    double internacoes_7v7;
    int pacientes_uti_ultimo_dia;
    int total_covid_uti_ultimo_dia;
    double ocupacao_leitos_ultimo_dia;
    int internacoes;
    double pacientes_enf_mm7d;
    double total_covid_enf_mm7d;
    int pacientes_enf_ultimo_dia;
    int total_covid_enf_ultimo_dia;
    int flag;
};

struct Filedata Data[limite];

int comparador(const void *a, const void *b)
{

    const struct Filedata *elem1 = a;
    const struct Filedata *elem2 = b;

    if (elem1->internacoes < elem2->internacoes)
        return -1;
    else if (elem1->internacoes > elem2->internacoes)
        return 1;
    else
        return 0;
}

void nomes_RM(){
    printf("***********************************************************************************\n");
    printf("*                   Amanda Naraoka                      6992344                   *\n");
    printf("*                   Felipe de Abreu VIljoen             4583472                   *\n");
    printf("*                   Guilherme de Carvalho Ferreira      1975118                   *\n");
    printf("*                   Lucas Vinicius Dimarzio Carneiro    6378748                   *\n");
    printf("*                   Marcelo Berger Gil                  8807370                   *\n");
    printf("***********************************************************************************\n");
    printf("*                   Arquivo ordenado com sucesso!                                 *\n");
    printf("***********************************************************************************\n");
}

int main()
{
    int i, j = 0, fim=0, cntflag1 = 0, n = 0;
    double cmp_next;
    char buffer[1024], *nfile;

    setlocale(LC_ALL, "Portuguese_Brazil");

    FILE *p;
    FILE *o;

    nfile = malloc(30);

    if ((p = fopen(NOMEARQUIVO, "r")) == NULL)
    {
        printf("file cannot be opened");
        exit (1);
    }

    fgets(buffer, sizeof(buffer), p);

    for (i = 0; i<limite; i++)
    {
        fgets(buffer, sizeof(buffer), p);

        strcpy(Data[i].datahora, strtok(buffer, ";"));

        strcpy(Data[i].nome, strtok(NULL, ";"));

        Data[i].pacientes_uti_mm7d = atof(strtok(NULL, ";"));

        Data[i].total_covid_uti_mm7d = atof(strtok(NULL, ";"));

        Data[i].ocupacao_leitos = atof(strtok(NULL, ";"));

        Data[i].pop = atoi(strtok(NULL, ";"));

        Data[i].leitos_pc = atof(strtok(NULL, ";"));

        Data[i].internacoes_7d = atoi(strtok(NULL, ";"));

        Data[i].internacoes_7d_l = atoi(strtok(NULL, ";"));

        Data[i].internacoes_7v7 = atof(strtok(NULL, ";"));

        Data[i].pacientes_uti_ultimo_dia = atoi(strtok(NULL, ";"));

        Data[i].total_covid_uti_ultimo_dia = atoi(strtok(NULL, ";"));

        Data[i].ocupacao_leitos_ultimo_dia = atof(strtok(NULL, ";"));

        Data[i].internacoes = atoi(strtok(NULL, ";"));

        Data[i].pacientes_enf_mm7d = atof(strtok(NULL, ";"));

        Data[i].total_covid_enf_mm7d = atof(strtok(NULL, ";"));

        Data[i].pacientes_enf_ultimo_dia = atoi(strtok(NULL, ";"));

        Data[i].total_covid_enf_ultimo_dia = atoi(strtok(NULL, ";"));
    }

    qsort(Data,limite,sizeof(struct Filedata), &comparador);

    while(Data[0].flag != 3)
    {
        for(i=0; i<limite; i++)
        {
            Data[i].flag = 0;
        }

        cntflag1=0;

        sprintf(nfile, "cvd19_%d.csv", n);

        o = fopen (nfile, "w");


        while(Data[0].flag != 1 && Data[0].flag != 3)
        {

            if(fgets(buffer, sizeof(buffer),p)!=NULL )
            {
                fprintf(o,"%s;%s;%f;%f;%f;%d;%f;%d;%d;%f;%d;%d;%f;%d;%f;%f;%d;%d\n", Data[0].datahora, Data[0].nome, Data[0].pacientes_uti_mm7d, Data[0].total_covid_uti_mm7d, Data[0].ocupacao_leitos, Data[0].pop, Data[0].leitos_pc, Data[0].internacoes_7d, Data[0].internacoes_7d_l, Data[0].internacoes_7v7,  Data[0].pacientes_uti_ultimo_dia, Data[0].total_covid_uti_ultimo_dia, Data[0].ocupacao_leitos_ultimo_dia,  Data[0].internacoes, Data[0].pacientes_enf_mm7d, Data[0].total_covid_enf_mm7d, Data[0].pacientes_enf_ultimo_dia, Data[0].total_covid_enf_ultimo_dia);

                cmp_next = Data[0].internacoes;

                strcpy(Data[0].datahora, strtok(buffer, ";"));

                strcpy(Data[0].nome, strtok(NULL, ";"));

                Data[0].pacientes_uti_mm7d = atof(strtok(NULL, ";"));

                Data[0].total_covid_uti_mm7d = atof(strtok(NULL, ";"));

                Data[0].ocupacao_leitos = atof(strtok(NULL, ";"));

                Data[0].pop = atoi(strtok(NULL, ";"));

                Data[0].leitos_pc = atof(strtok(NULL, ";"));

                Data[0].internacoes_7d = atoi(strtok(NULL, ";"));

                Data[0].internacoes_7d_l = atoi(strtok(NULL, ";"));

                Data[0].internacoes_7v7 = atof(strtok(NULL, ";"));

                Data[0].pacientes_uti_ultimo_dia = atoi(strtok(NULL, ";"));

                Data[0].total_covid_uti_ultimo_dia = atoi(strtok(NULL, ";"));

                Data[0].ocupacao_leitos_ultimo_dia = atof(strtok(NULL, ";"));

                Data[0].internacoes = atoi(strtok(NULL, ";"));

                Data[0].pacientes_enf_mm7d = atof(strtok(NULL, ";"));

                Data[0].total_covid_enf_mm7d = atof(strtok(NULL, ";"));

                Data[0].pacientes_enf_ultimo_dia = atoi(strtok(NULL, ";"));

                Data[0].total_covid_enf_ultimo_dia = atoi(strtok(NULL, ";"));

                Data[0].flag = 0;

                if(Data[0].internacoes>cmp_next)
                {
                    fim=limite-cntflag1;
                    organizar(fim);
                }
                else if(Data[0].internacoes<cmp_next)
                {
                    cntflag1++;
                    fim=limite-cntflag1;
                    shift_left(fim);
                }
            }
            else
            {
                fclose(p);
                while(Data[j].flag!=1)
                {
                    fprintf(o,"%s;%s;%f;%f;%f;%d;%f;%d;%d;%f;%d;%d;%f;%d;%f;%f;%d;%d\n", Data[j].datahora, Data[j].nome, Data[j].pacientes_uti_mm7d, Data[j].total_covid_uti_mm7d, Data[j].ocupacao_leitos, Data[j].pop, Data[j].leitos_pc, Data[j].internacoes_7d, Data[j].internacoes_7d_l, Data[j].internacoes_7v7,  Data[j].pacientes_uti_ultimo_dia, Data[j].total_covid_uti_ultimo_dia, Data[j].ocupacao_leitos_ultimo_dia,  Data[j].internacoes, Data[j].pacientes_enf_mm7d, Data[j].total_covid_enf_mm7d, Data[j].pacientes_enf_ultimo_dia, Data[j].total_covid_enf_ultimo_dia);
                    j++;
                }
                fclose(o);
                n++;
                sprintf(nfile, "cvd19_%d.csv", n);
                o = fopen (nfile, "w+");
                Data[limite-1].flag=3;
                for(i=j; i<limite; i++)
                {
                    fprintf(o,"%s;%s;%f;%f;%f;%d;%f;%d;%d;%f;%d;%d;%f;%d;%f;%f;%d;%d\n", Data[i].datahora, Data[i].nome, Data[i].pacientes_uti_mm7d, Data[i].total_covid_uti_mm7d, Data[i].ocupacao_leitos, Data[i].pop, Data[i].leitos_pc, Data[i].internacoes_7d, Data[i].internacoes_7d_l, Data[i].internacoes_7v7,  Data[i].pacientes_uti_ultimo_dia, Data[i].total_covid_uti_ultimo_dia, Data[i].ocupacao_leitos_ultimo_dia,  Data[i].internacoes, Data[i].pacientes_enf_mm7d, Data[i].total_covid_enf_mm7d, Data[i].pacientes_enf_ultimo_dia, Data[i].total_covid_enf_ultimo_dia);
                }
                Data[0].flag=3;
            }
        }
        fclose(o);
        n++;
    }

    free(nfile);
    Mergefiles(n);

    nomes_RM();

    return 0;
}


void organizar(int c)
{
    int pos=0;

    struct Filedata temp1 = Data[0];

    while(temp1.internacoes>Data[pos+1].internacoes && pos+1<c)
    {
        Data[pos]=Data[pos+1];
        pos++;
    }

    Data[pos] = temp1;

    return;
}


void shift_left(int d)
{
    int i;

    struct Filedata temp2 = Data[0];

    for(i= 0; i < d; i++)
    {
        Data[i] = Data[i+1];
    }

    while(temp2.internacoes>Data[d+1].internacoes && d+1<limite)
    {
        Data[d]=Data[d+1];
        d++;
    }
    Data[d] = temp2;
    Data[d].flag = 1;

    return;
}

typedef struct
{
    char *datah;
    char *nomes;
    double pacientes_uti_mm7dn;
    double total_covid_uti_mm7dn;
    double ocupacao_leitosn;
    int popn;
    double leitos_pcn;
    int internacoes_7dn;
    int internacoes_7d_ln;
    double internacoes_7v7n;
    int pacientes_uti_ultimo_dian;
    int total_covid_uti_ultimo_dian;
    double ocupacao_leitos_ultimo_dian;
    int intern;
    double pacientes_enf_mm7dn;
    double total_covid_enf_mm7dn;
    int pacientes_enf_ultimo_dian;
    int total_covid_enf_ultimo_dian;
    int pos;
    int state;
} Ndata;

void Mergefiles(int n)
{

    int i, tmn=0, marcador;
    char  linha[1024], **flname;

    tmn = n + (n-1);

    FILE **fp;
    FILE *fim;

    Ndata *sorted;

    fp = malloc(sizeof(*fp)*(n-1));
    flname = malloc((n)*sizeof(char*));
    sorted = malloc(tmn*sizeof(Ndata));

    for(i=0; i<n; i++)
    {
        flname[i] = malloc(50*sizeof(char));
    }

    for(i=0; i<tmn; i++)
    {
        sorted[i].datah = malloc(100);
        sorted[i].nomes = malloc(100);
    }


    for(i=0; i<n; i++)
    {
        sprintf(flname[i],"cvd19_%d.csv", i);
        if ((fp[i] = fopen(flname[i], "r")) == NULL)
        {
            printf("file cannot be opened");
            exit (2);
        }
        fgets(linha, sizeof (linha), fp[i]);
        strcpy(sorted[i].datah, strtok(linha, ";"));
        strcpy(sorted[i].nomes, strtok(NULL, ";"));
        sorted[i].pacientes_uti_mm7dn = atof(strtok(NULL, ";"));
        sorted[i].total_covid_uti_mm7dn = atof(strtok(NULL, ";"));
        sorted[i].ocupacao_leitosn = atof(strtok(NULL, ";"));
        sorted[i].popn = atoi(strtok(NULL, ";"));
        sorted[i].leitos_pcn = atof(strtok(NULL, ";"));
        sorted[i].internacoes_7dn = atoi(strtok(NULL, ";"));
        sorted[i].internacoes_7d_ln = atoi(strtok(NULL, ";"));
        sorted[i].internacoes_7v7n = atof(strtok(NULL, ";"));
        sorted[i].pacientes_uti_ultimo_dian = atoi(strtok(NULL, ";"));
        sorted[i].total_covid_uti_ultimo_dian = atoi(strtok(NULL, ";"));
        sorted[i].ocupacao_leitos_ultimo_dian = atof(strtok(NULL, ";"));
        sorted[i].intern = atoi(strtok(NULL, ";"));
        sorted[i].pacientes_enf_mm7dn = atof(strtok(NULL, ";"));
        sorted[i].total_covid_enf_mm7dn = atof(strtok(NULL, ";"));
        sorted[i].pacientes_enf_ultimo_dian = atoi(strtok(NULL, ";"));
        sorted[i].total_covid_enf_ultimo_dian = atoi(strtok(NULL, ";"));
        sorted[i].pos = i;
        sorted[i].state = 0;
    }

    fim = fopen("cvd19_Merged.csv", "w+");
    fprintf(fim,"datahora;nome_drs;pacientes_uti_mm7d;total_covid_uti_mm7d;ocupacao_leitos;pop;leitos_pc;internacoes_7d;internacoes_7d_l;internacoes_7v7;pacientes_uti_ultimo_dia;total_covid_uti_ultimo_dia;ocupacao_leitos_ultimo_dia;internacoes_ultimo_dia;pacientes_enf_mm7d;total_covid_enf_mm7d;pacientes_enf_ultimo_dia;total_covid_enf_ultimo_dia\n");

    int cnt = 0, file_end=0, min;

    while(file_end!=n)
    {
        for(i=0; i<tmn-1; i++)
        {
            if(sorted[i].intern<=sorted[i+1].intern)
            {
                min = i;
            }
            else
            {
                min = i+1;
            }
            if(sorted[i].state==1)
            {
                min=i+1;
            }
            else if(sorted[i+1].state==1)
            {
                min=i;
            }

            strcpy(sorted[n+cnt].datah, sorted[min].datah);
            strcpy(sorted[n+cnt].nomes, sorted[min].nomes);
            sorted[n+cnt].pacientes_uti_mm7dn = sorted[min].pacientes_uti_mm7dn;
            sorted[n+cnt].total_covid_uti_mm7dn = sorted[min].total_covid_uti_mm7dn;
            sorted[n+cnt].ocupacao_leitosn = sorted[min].ocupacao_leitosn;
            sorted[n+cnt].popn = sorted[min].popn;
            sorted[n+cnt].leitos_pcn = sorted[min].leitos_pcn;
            sorted[n+cnt].internacoes_7dn = sorted[min].internacoes_7dn;
            sorted[n+cnt].internacoes_7d_ln = sorted[min].internacoes_7d_ln;
            sorted[n+cnt].internacoes_7v7n = sorted[min].internacoes_7v7n;
            sorted[n+cnt].pacientes_uti_ultimo_dian = sorted[min].pacientes_uti_ultimo_dian;
            sorted[n+cnt].total_covid_uti_ultimo_dian = sorted[min].total_covid_uti_ultimo_dian;
            sorted[n+cnt].ocupacao_leitos_ultimo_dian = sorted[min].ocupacao_leitos_ultimo_dian;
            sorted[n+cnt].intern = sorted[min].intern;
            sorted[n+cnt].pacientes_enf_mm7dn = sorted[min].pacientes_enf_mm7dn;
            sorted[n+cnt].total_covid_enf_mm7dn = sorted[min].total_covid_enf_mm7dn;
            sorted[n+cnt].pacientes_enf_ultimo_dian = sorted[min].pacientes_enf_ultimo_dian;
            sorted[n+cnt].total_covid_enf_ultimo_dian = sorted[min].total_covid_enf_ultimo_dian;
            sorted[n+cnt].pos = sorted[min].pos;
            sorted[n+cnt].state = sorted[min].state;
            cnt++;
            i++;
        }

        marcador = sorted[tmn-1].pos;

        if(fgets(linha, sizeof (linha), fp[marcador])!=NULL)
        {
            strcpy(sorted[marcador].datah, strtok(linha, ";"));
            strcpy(sorted[marcador].nomes, strtok(NULL, ";"));
            sorted[marcador].pacientes_uti_mm7dn = atof(strtok(NULL, ";"));
            sorted[marcador].total_covid_uti_mm7dn = atof(strtok(NULL, ";"));
            sorted[marcador].ocupacao_leitosn = atof(strtok(NULL, ";"));
            sorted[marcador].popn = atoi(strtok(NULL, ";"));
            sorted[marcador].leitos_pcn = atof(strtok(NULL, ";"));
            sorted[marcador].internacoes_7dn = atoi(strtok(NULL, ";"));
            sorted[marcador].internacoes_7d_ln = atoi(strtok(NULL, ";"));
            sorted[marcador].internacoes_7v7n = atof(strtok(NULL, ";"));
            sorted[marcador].pacientes_uti_ultimo_dian = atoi(strtok(NULL, ";"));
            sorted[marcador].total_covid_uti_ultimo_dian = atoi(strtok(NULL, ";"));
            sorted[marcador].ocupacao_leitos_ultimo_dian = atof(strtok(NULL, ";"));
            sorted[marcador].intern = atoi(strtok(NULL, ";"));
            sorted[marcador].pacientes_enf_mm7dn = atof(strtok(NULL, ";"));
            sorted[marcador].total_covid_enf_mm7dn = atof(strtok(NULL, ";"));
            sorted[marcador].pacientes_enf_ultimo_dian = atoi(strtok(NULL, ";"));
            sorted[marcador].total_covid_enf_ultimo_dian = atoi(strtok(NULL, ";"));
            if(n%2!=0 && marcador == n-1){
                i = marcador;
            }
            else if(marcador%2!=0)
            {
                i = marcador-1;
            }
            else
            {
                i = marcador;
            }
        }
        else
        {
            i=0;
            file_end++;
            sorted[marcador].state = 1;
        }
        fprintf(fim,"%s;%s;%.2f;%.2f;%.2f;%d;%.2f;%d;%d;%.2f;%d;%d;%.2f;%d;%.2f;%.2f;%d;%d\n", sorted[tmn-1].datah, sorted[tmn-1].nomes, sorted[tmn-1].pacientes_uti_mm7dn, sorted[tmn-1].total_covid_uti_mm7dn, sorted[tmn-1].ocupacao_leitosn, sorted[tmn-1].popn, sorted[tmn-1].leitos_pcn, sorted[tmn-1].internacoes_7dn, sorted[tmn-1].internacoes_7d_ln, sorted[tmn-1].internacoes_7v7n, sorted[tmn-1].pacientes_uti_ultimo_dian, sorted[tmn-1].total_covid_uti_ultimo_dian, sorted[tmn-1].ocupacao_leitos_ultimo_dian, sorted[tmn-1].intern, sorted[tmn-1].pacientes_enf_mm7dn, sorted[tmn-1].total_covid_enf_mm7dn, sorted[tmn-1].pacientes_enf_ultimo_dian, sorted[tmn-1].total_covid_enf_ultimo_dian);
        cnt=0;
    }

    for(i=0; i<n; i++)
    {
        fclose(fp[i]);
        free(flname[i]);
    }

    for(i=0; i<tmn; i++)
    {
        free(sorted[i].datah);
        free(sorted[i].nomes);
    }

    fclose(fim);
    free(sorted);
    free(flname);
    free(fp);
    return;
}
